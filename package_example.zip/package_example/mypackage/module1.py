# module1.py

def greet(name): 
    print(f"Hello, {name}!")

def mean_cal(x): 
    result = sum(x)/len(x)
    return result

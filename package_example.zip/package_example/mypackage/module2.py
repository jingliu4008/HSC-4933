# module2.py
def depart(name): 
    print(f"Goodbye, {name}!")


from mypackage.module1 import mean_cal

def SD_cal(x): 
    mean = mean_cal(x)
    variance = sum((xi - mean for xi in x))/(len(x)-1)
    sd = variance**0.5
    return sd

x = [2, 4, 6, 8, 10]
# Calling the mean_cal function from module1
mean_value = mean_cal(x)
print("Mean:", mean_value)

# Calling the SD_cal function from module2
sd_value = SD_cal(x)
print("Standard Deviation:", sd_value)

# main_exmp.py
from mypackage import module1, module2

module1.greet("Pythonista")
module2.depart("Pythonista")

x = [2, 4, 6, 8, 10]

# Calling the mean_cal function from module1
mean_value = module1.mean_cal(x)
print("Mean:", mean_value)

# Calling the SD_cal function from module2
sd_value = module2.SD_cal(x)
print("Standard Deviation:", sd_value)
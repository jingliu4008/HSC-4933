# main.py
"""need to import all the files you want to use then you can call them out later"""
import mypackage.module1
import mypackage.module2

mypackage.module1.greet("Pythonista")
mypackage.module2.depart("Pythonista")

x = [2, 4, 6, 8, 10]

# Calling the mean_cal function from module1
mean_value = mypackage.module1.mean_cal(x)
print("Mean:", mean_value)

# Calling the SD_cal function from module2
sd_value = mypackage.module2.SD_cal(x)
print("Standard Deviation:", sd_value)
